Maintainer
``````````

- Amos Bastian <amosbastian@gmail.com> `@amosbastian <https://github.com/amosbastian>`_

Contributors
````````````

- Chris Musson <chris.musson@hotmail.com> `@ChrisMusson <https://github.com/ChrisMusson>`_