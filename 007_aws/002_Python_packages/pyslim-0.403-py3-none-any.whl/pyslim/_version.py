# coding: utf-8
pyslim_version = '0.403'
